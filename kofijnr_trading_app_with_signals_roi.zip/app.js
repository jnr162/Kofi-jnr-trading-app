
const apiKey = "1SNMDXPIT2WAX906";
const assets = {
  crypto: ["BTCUSD", "ETHUSD", "SOLUSD", "DOGEUSD"],
  forex: ["XAUUSD", "GBPJPY"]
};

function switchTab(tab) {
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  document.getElementById(tab).classList.add("active");

  document.querySelectorAll("nav button").forEach(b => b.classList.remove("active"));
  document.getElementById("btn-" + tab).classList.add("active");
}

async function fetchData(symbol, containerId) {
  const base = symbol.slice(0, 3);
  const quote = symbol.slice(3);
  const url = `https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=${base}&to_currency=${quote}&apikey=${apiKey}`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    const price = data["Realtime Currency Exchange Rate"]?.["5. Exchange Rate"] || "N/A";

    const buyConfidence = Math.floor(Math.random() * 41 + 50);
    const sellConfidence = 100 - buyConfidence;

    const roi30 = Math.floor(Math.random() * 10 + 1);
    const roi60 = Math.floor(Math.random() * 15 + 5);
    const prediction = buyConfidence > sellConfidence ? "Buy" : "Sell";

    const container = document.getElementById(containerId);
    container.innerHTML = `
      <h3>${base}/${quote}</h3>
      <p>Price: $${parseFloat(price).toFixed(4)}</p>
      <div class="signal-box">Buy: ${buyConfidence}%, Sell: ${sellConfidence}%</div>
      <div class="roi-box">Next 30min: ${prediction} ROI ~${roi30}% | Next 1hr: ${prediction} ROI ~${roi60}%</div>
      <canvas id="chart-${symbol}"></canvas>
    `;

    drawChart(`chart-${symbol}`);
  } catch (error) {
    console.error("Error fetching data for", symbol, error);
  }
}

function drawChart(canvasId) {
  const ctx = document.getElementById(canvasId).getContext("2d");
  new Chart(ctx, {
    type: "line",
    data: {
      labels: Array.from({ length: 10 }, (_, i) => `T-${10 - i}`),
      datasets: [{
        label: "Simulated Price",
        data: Array.from({ length: 10 }, () => (Math.random() * 1000 + 500)),
        borderColor: "rgba(46, 204, 113, 1)",
        backgroundColor: "rgba(46, 204, 113, 0.2)",
        fill: true
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: false } }
    }
  });
}

window.onload = () => {
  [...assets.crypto, ...assets.forex].forEach(symbol => fetchData(symbol, symbol));
};
